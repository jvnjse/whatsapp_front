const config = {
  baseUrl: "https://altosconnectweb.com/",
  imagebaseurl: "https://altosconnectweb.com",
  // baseUrl: "http://127.0.0.1:8000/",
  // imagebaseurl: "http://127.0.0.1:8000",
};

export default config;
